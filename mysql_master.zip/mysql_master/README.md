CHANGE MASTER TO
    -> MASTER_HOST='mysql-master',
    -> MASTER_USER='repl',
    -> MASTER_PASSWORD='secret',
    -> MASTER_LOG_FILE='mysql-bin.000007',
    -> MASTER_LOG_POS=660;
